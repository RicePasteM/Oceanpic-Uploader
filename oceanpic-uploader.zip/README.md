## picgo-plugin-oceanpic-uploader

A Picgo uploader plugin for OceanPic.
